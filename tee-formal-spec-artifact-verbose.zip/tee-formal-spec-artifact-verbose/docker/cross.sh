#!/bin/bash

# build script for cross build
docker buildx create --use --name crossbuild 
docker buildx inspect --bootstrap
docker buildx build --tag tee-formal-spec:artifact --push --platform linux/amd64,linux/arm64 ..
docker buildx rm crossbuild