#!/bin/bash
out_dir=$(pwd)/out

rm -rf $out_dir

mkdir -p $out_dir && cd $out_dir
(
docker cp tee-formal-spec:/home/fase2024/artifact/scripts/ ./
mv scripts/* ./
rm -rf gen-report gen-table run run-exp scripts
)