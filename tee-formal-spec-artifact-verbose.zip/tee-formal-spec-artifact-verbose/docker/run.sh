#!/bin/bash
docker load -i img.tar
docker run --rm -it --name tee-formal-spec --hostname ubuntu \
  --platform linux/amd64 tee-formal-spec:artifact