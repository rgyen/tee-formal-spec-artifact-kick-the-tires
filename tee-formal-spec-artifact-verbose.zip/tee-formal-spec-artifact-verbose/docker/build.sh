#!/bin/bash

docker build --tag tee-formal-spec:artifact ..
docker save -o img.tar tee-formal-spec:artifact